function f1() {
  return "I'm function 1";
}

console.log(`Function 1: ${f1()}`);

function f2() {
  return "I'm function 2";
}
console.log(`Function 2: ${f2()}`);
