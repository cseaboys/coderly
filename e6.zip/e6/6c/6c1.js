function sayHello(){
  console.log("Hello");
  
}

module.exports = {sayHello}