const {sayHello} = require("./6c1")

sayHello();